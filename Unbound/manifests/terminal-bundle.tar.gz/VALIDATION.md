# Offline retry qualification

Fourteen tests passed in Unbound/tests/test_host_records.py, now invoked by the
repository Unbound/tests/run.sh. Coverage includes atomic replacement failure,
metadata/drift/symlink and hash gates, reload then two healthy samples, flapping,
permanent reload timeout, hard/peer failures, VIP movement, strict preflight,
cursor banner parsing, explicit rollback reload failure and the real apply
transaction recovering successfully or reporting recovery failure. Native
candidate checks from readiness remain valid for the unchanged candidate and
expanded configuration bytes, subject to execution-time hash checks.

No production contact or mutation occurred while repairing the helper. These
fixtures do not establish live service settlement or DNS recovery. The manual
ordered gate and exact rollback in EXECUTION.md remain mandatory.
