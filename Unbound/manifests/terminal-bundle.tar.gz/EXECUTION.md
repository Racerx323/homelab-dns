# Exact DNS retry deployment bundle

Prepared only. Authorization must name the SHA-256 of SHA256SUMS and this entire
ordered procedure. Execute from this bundle directory. HASH below means that
exact approved digest, not the candidate file digest. No command below has run.

1. Verify every SHA256SUMS entry locally with `sha256sum -c SHA256SUMS`.
   Re-read current roles, native validation, file/binary/sync hashes and service
   health. node.py enforces those preconditions again per node. Confirm no parallel
   writer or active peer deployment. If readiness changed, stop and re-review.
2. Run `python3 dispatch.py HASH secondary apply`. Nonzero means stop and review
   the retained stdout/stderr/status. Never retry blindly after SSH loss/timeout;
   determine actual remote state and whether automatic node rollback ran.
3. Run `python3 verify.py secondary`. Require all eight direct-node DNS answers.
   Also run the loopback and existing-record/service checks listed below. Confirm
   primary still serves baseline DNS and owns both VIPs. No peer progression if
   any check fails. If only cached NXDOMAIN remains while loopback data is correct,
   retry every 15 seconds for at most 120 seconds, preserving each result. No
   global flush/restart. If still failing, roll back secondary and stop.
4. Run `python3 dispatch.py HASH primary apply`, then `python3 verify.py primary`.
   Repeat the same health checks and bounded cache wait. On failure, restore
   primary then secondary, verifying each restoration, and stop.
5. Run `python3 verify.py all` for all 24 node/VIP results. Repeat both FQDN SSH
   checks as described below. Any unresolved failure means no acceptance; restore
   both changed nodes in reverse order unless recovery itself is unsafe.

## Additional exact validation commands

On each changed node, through strict-key SSH as pi, capture stdout/stderr/status:

```text
sudo unbound-control status
sudo unbound-checkconf /etc/unbound/unbound.conf
systemctl is-active unbound pihole-FTL keepalived
ip -json address
sudo ss -lntup
```

Require active services, unchanged VIP owner and Unbound port 5335 only on loopback.
Using `dig +time=3 +tries=1`, run the same four host questions as verify.py against
both `@127.0.0.1 -p 5335` and `@::1 -p 5335` on each node. Require exact answers.
Check `pihole.local.theama.co. A` through that node's two LAN endpoints returns
only `10.1.0.55`; `example.com. A` must remain NOERROR with a nonempty answer.
Capture only unbound unit journal messages after the exact cursor retained in
`/var/backups/nautobot-host-dns-20260921-retry1/journal-cursor.txt`, using a 64 KiB bound.
A new Unbound error stops progression for review.

After all DNS gates, on the existing controller:

```bash
ssh -4 -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=6 -o HostKeyAlias=10.1.2.170 ama@j2-svpi4mf.local.theama.co 'hostnamectl --static && cat /proc/sys/kernel/random/boot_id'
ssh -6 -o BatchMode=yes -o StrictHostKeyChecking=yes -o ConnectTimeout=6 -o HostKeyAlias=10.1.2.170 ama@j2-svpi4mf.local.theama.co 'hostnamectl --static && cat /proc/sys/kernel/random/boot_id'
```

Use a 20-second outer timeout. Expected hostname j2-svpi4mf and retained boot
70c9f650-a6a2-4583-84a9-f96462bef393; boot drift requires review. The explicit
host-key alias uses the authenticated IPv4 identity; it does not override DNS.

## Exact rollback

Run `python3 dispatch.py HASH primary rollback` if primary changed, then
`python3 dispatch.py HASH secondary rollback` if secondary changed. These restore
each node's original bytes and root:root mode 0644, validate and reload Unbound.
They will not overwrite a third-party destination change. Unreachable nodes or
changed prerequisites require manual recovery; do not assume rollback succeeded.

Recheck the backup/original destination hash from operation.json, service health,
VIP ownership and original NXDOMAIN answers plus existing local/public controls.
Use direct Unbound readback to distinguish restored state from positive Pi-hole
cache entries; bounded expiry may still leave client-side caches. Preserve all
results. Never use verify.py's positive-answer success as a rollback test.

The node helper automatically restores the exact backup after caught replacement,
validation, reload or immediate-health errors, but that is not DNS acceptance.
A controller timeout or process kill can leave state unknown. Retained backups
remain on nodes; deleting them is not authorized by deployment. No services other
than Unbound may be reloaded/restarted, no sync changes or VIP movement, and no
packages, host-network, Caddy, Webmin, SMART, Restic, Git commit or push changes.

## Retry-specific controls

The original failed bundle and original node backup must not be changed. This
retry uses its own SHA256SUMS digest and a new exclusive backup directory. The
node helpers require bounded 30-second settlement after each reload, with two
active/running samples separated by one second. Only Unbound reloading is
tolerated; other unhealthy states and VIP drift fail immediately. Service samples
and both apply/recovery errors are emitted into retained controller evidence.

The journal-cursor file now contains just the parsed cursor token plus newline;
use that token directly with --after-cursor. No banner stripping is needed.
The dispatcher has a 300-second outer bound; timeout means inspect before doing
anything else, never assume remote rollback. Existing readiness is retained,
not freshly collected for this retry. All hash/metadata/include/role gates must
pass anew in the actual execution. No new automatic peer progression is added.
